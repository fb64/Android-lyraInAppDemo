package com.lyranetwork.cheesecake;


import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.lyranetwork.cheesecake.data.Cart;
import com.lyranetwork.cheesecake.data.Order;
import com.lyranetwork.payment.PaymentManager;
import com.lyranetwork.payment.error.PaymentError;
import com.lyranetwork.payment.json.PaymentInit;
import com.lyranetwork.payment.json.PaymentInitResult;

import java.util.List;

/**
 * Created by agiuliani on 27/09/2016.
 */

public class CartActivity extends AppCompatActivity {

    private static String TAG = CartActivity.class.getName();

    Cart myCart = MainApplication.get().getMyCart();
    private TextView mTotal;
    private Button mPay;
    private CartListAdapter mAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        mTotal = (TextView) findViewById(R.id.cart_total);

        TextView mTitle = (TextView) findViewById(R.id.cart_main_title);
        mTitle.setTypeface(MainApplication.get().getIndieFlowerFont());

        Button mClear = (Button) findViewById(R.id.clear);
        mClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myCart.getOrders().clear();
                mAdapter.clear();
                updateTotal();
            }
        });

        RecyclerView mRecyclerView = (RecyclerView) findViewById(R.id.cart_list);
        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        List<Order> orders = myCart.getOrders();
        Order[] data = orders.toArray(new Order[orders.size()]);
        mAdapter = new CartListAdapter(data);
        mRecyclerView.setAdapter(mAdapter);

        mPay = (Button) findViewById(R.id.pay);
        mPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makePayment();
            }
        });

        MainApplication.get().getMyCart().setOnCartAdded(new Cart.OnCartUpdate() {
            @Override
            public void onUpdate() {
                updateTotal();
            }
        });
        updateTotal();
    }

    private void makePayment() {
        final Double total = myCart.total() * 100;
        final Integer formatedAmount = total.intValue();

        final Activity activity = this;

        final ProgressDialog mainDialog = new ProgressDialog(this);
        mainDialog.setMessage(getString(R.string.loading));
        mainDialog.setCancelable(false);
        mainDialog.setIndeterminate(true);
        mainDialog.show();

        new AsyncTask<Void, Void, PaymentInitResult>() {
            @Override
            protected PaymentInitResult doInBackground(Void... params) {
                try {
                    //payment amount must be sent before, to handle amount/cart from merchant server
                    return PaymentManager.get().preparePayment(new PaymentInit());
                } catch (Exception error) {
                    Log.e(TAG, "Got error while asking for payment : " + error);
                    return null;
                }
            }

            @Override
            protected void onPostExecute(PaymentInitResult result) {
                mainDialog.dismiss();
                if (result != null && result.getSuccess()) {
                    try {
                        PaymentManager.get().showPayment(result, activity, BackActivity.class);
                    } catch (PaymentError paymentError) {
                        paymentError.printStackTrace();
                        showError();
                    }
                } else {
                    showError();
                }
            }
        }.execute();
    }

    private void showError() {
        Snackbar.make(mPay, "Error : Couldn't obtain payment token. Please, try again !", Snackbar.LENGTH_LONG).show();
    }

    public void updateTotal() {
        mTotal.setText(String.format("%s €", myCart.total()));
    }
}
