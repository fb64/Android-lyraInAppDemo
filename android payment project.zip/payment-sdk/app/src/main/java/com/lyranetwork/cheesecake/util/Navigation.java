package com.lyranetwork.cheesecake.util;

import android.app.Activity;
import android.content.Intent;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;

/**
 * Created by agiuliani on 27/09/2016.
 */

public class Navigation {

    public static void open(Activity ctx, Class<? extends Activity> target, boolean hasBack) {
        Intent intent = new Intent(ctx, target);
        if (!hasBack) {
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        ActivityOptionsCompat options = ActivityOptionsCompat.makeCustomAnimation(ctx, android.R.anim.fade_in, android.R.anim.fade_out);
        ActivityCompat.startActivity(ctx, intent, options.toBundle());
    }
}
