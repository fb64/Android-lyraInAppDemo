package com.lyranetwork.cheesecake;

import android.app.Application;
import android.graphics.Typeface;

import com.joanzapata.iconify.Iconify;
import com.joanzapata.iconify.fonts.FontAwesomeModule;
import com.joanzapata.iconify.fonts.MaterialModule;
import com.lyranetwork.cheesecake.data.Cart;
import com.lyranetwork.cheesecake.data.Order;
import com.lyranetwork.payment.PaymentManager;

/**
 * Created by agiuliani on 22/09/2016.
 */

public class MainApplication extends Application {

    //static data
    final static public Order[] AVAILABLE_ORDERS = {new Order("The Original", R.drawable.cc_500_350, 5.0), new Order("Triple Chocolate", R.drawable.cc2_500_350, 5.5),
            new Order("Blueberry", R.drawable.cc3_500_350, 5.25), new Order("Coffee Cream", R.drawable.cc4_500_350, 4.7)};
    private static MainApplication instance;
    private Typeface indieFlowerFont;
    private Cart myCart = new Cart();

    public static MainApplication get() {
        return instance;
    }

    public Typeface getIndieFlowerFont() {
        return indieFlowerFont;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        Iconify.with(new MaterialModule())
                .with(new FontAwesomeModule());

        indieFlowerFont = Typeface.createFromAsset(getAssets(), "fonts/indieflower.ttf");

        PaymentManager.init("91335531","http://cr7.sandbox.ptitp.eu:9090/performInit");

        instance = this;
    }

    public Cart getMyCart() {
        return myCart;
    }
}
