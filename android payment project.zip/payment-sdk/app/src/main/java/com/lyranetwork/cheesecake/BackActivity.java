package com.lyranetwork.cheesecake;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.joanzapata.iconify.widget.IconTextView;
import com.lyranetwork.cheesecake.util.Navigation;
import com.lyranetwork.payment.PaymentManager;
import com.lyranetwork.payment.json.PaymentResult;

public class BackActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_back);

        PaymentResult paymentResult = PaymentManager.get().getResultFromUrl(getIntent().getStringExtra(PaymentManager.BUNDLE_RESULT));

        IconTextView icon = (IconTextView) findViewById(R.id.back_icon);
        TextView title = (TextView) findViewById(R.id.back_title);
        title.setTypeface(MainApplication.get().getIndieFlowerFont());
        if (paymentResult != null && paymentResult.isSuccess()) {
            icon.setText("{fa-check-square-o}");
            title.setText(getString(R.string.payment_succeed));
        } else {
            icon.setText("{fa-exclamation-triangle}");
            String text = getString(R.string.payment_failure);
            if (paymentResult != null) {
                text += "\nStatus is '"+paymentResult.getResult()+"'";
            }
            title.setText(text);
        }

        MainApplication.get().getMyCart().getOrders().clear();

        Button button = (Button) findViewById(R.id.button_back);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.open(BackActivity.this, MainActivity.class, false);
            }
        });
    }

}
