package com.lyranetwork.payment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.google.gson.Gson;
import com.lyranetwork.payment.error.PaymentError;
import com.lyranetwork.payment.json.PaymentInit;
import com.lyranetwork.payment.json.PaymentInitResult;
import com.lyranetwork.payment.json.PaymentResult;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;

import static com.lyranetwork.payment.PaymentActivity.PAYZEN_URL;

/**
 * Manage the payment process
 */
public class PaymentManager {

    public static final String BUNDLE_RESULT = "PaymentResult";
    private static final String CALLBACK_URL_PREFIX = "http://webview_";
    private static final String MEDIATYPE_JSON = "application/json";

    private static PaymentManager INSTANCE;
    private final String mMerchantId;
    private OkHttpClient mHttpClient;
    private Class<? extends Activity> mCallbackActivity;
    private String mPostUrl;
    private Gson mGson = new Gson();

    private PaymentManager(String merchantId, String url) {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        mHttpClient = new OkHttpClient
                .Builder()
                .addInterceptor(logging)
                .build();

        mPostUrl = url;
        mMerchantId = merchantId;
    }

    /**
     * Requirements payment data
     * @param merchantId - merchant Id
     * @param postUrl        - web service url for posting init payment
     */
    public static void init(String merchantId, String postUrl) {
        INSTANCE = new PaymentManager(merchantId, postUrl);
    }

    @NonNull
    public static PaymentManager get() {
        return INSTANCE;
    }

    Class<? extends Activity> getmCallbackActivity() {
        return mCallbackActivity;
    }

    /**
     * Prepare payment process with merchant server
     * @param config
     * @return @see PaymentInitResult
     * @throws PaymentError
     */
    public PaymentInitResult preparePayment(PaymentInit config) throws PaymentError {
        try {
            Request request = new Request.Builder()
                    .url(mPostUrl)
                    .post(RequestBody.create(MediaType.parse(MEDIATYPE_JSON), mGson.toJson(config)))
                    .build();
            Response response = mHttpClient.newCall(request).execute();
            return mGson.fromJson(response.body().string(), PaymentInitResult.class);
        } catch (IOException e) {
            throw new PaymentError("Payment http request error", e);
        }
    }

    Boolean isCallbackUrl(String url) {
        return url.startsWith(CALLBACK_URL_PREFIX + mMerchantId + ".");
    }

    @Nullable
    public PaymentResult getResultFromUrl(String url) {
        if (url.startsWith(CALLBACK_URL_PREFIX + mMerchantId + ".")) {
            url = url.replace(CALLBACK_URL_PREFIX + mMerchantId + ".", "");
            String[] data = url.split("/");
            String addData = data[1].substring(1, data[1].length());
            return new PaymentResult(data[0], addData);
        }
        return null;
    }

    /**
     * Proceed payment in webview
     *
     * @param ctx              - Calling context
     * @param callbackActivity - Activity to call back
     * @throws IllegalStateException - SDK Error
     */
    public void showPayment(PaymentInitResult result, Context ctx, Class<? extends Activity> callbackActivity) throws PaymentError {
        if (result != null && result.getSuccess()) {
            this.mCallbackActivity = callbackActivity;
            Intent intent = new Intent(ctx, PaymentActivity.class);
            Bundle b = new Bundle();
            b.putString(PAYZEN_URL, result.getRedirect_url());
            intent.putExtras(b);
            ctx.startActivity(intent);
        } else {
            throw new PaymentError("Can't display a payment with PaymentInitResult falied or null");
        }
    }
}
