# Android payment with Payzen

This page describes how to embed payzen payment within your mobile application. 
  
__TODO :__ add links to java classes, in github with html links

## About this project

This Android project is made of 2 modules : 

* app - the _cheesecake demo application_
* payment - the _payzen payment module_

This project is using __Android API 19__ for minimum API level. The payment process is in a seperated module, to help identify the needed elements for payzen processing.
 

## The Cheesecake Application

The cheesecake application is an Android  demo application for _buying_ cheesecakes. The app is baed on the following views :

* __MainActivity__ - the main screen, the cake list
* __CartActivity__ - the ordering screen

![Main View](./img/app-main.png)
![Cart View](./img/app-cart.png)

### How this app works ?

The __MainActivity__ displays the cheescake list, ready to be added to the current _cart_. If you click on the _bottom area_, you will go to the __CartActivity__. This last view, display your cart before proceeding to payment.

The payment is started from __CartActivity__, via the `makePayment()` method, called by the _buy_ button.


## Making the payment


### Requirements

You need to provide the following information :

* merchant id - identifying payment results
* merchant service url - web service url used by the Android app


### Overview

The `PaymentManager` class is dedicated to help prepare and make the payment: 

* `preparePayment` - prepare payment and return `PaymentInitResult`
* `showPayment` - show the payment in a webview

You need to prepare an activity to be called back, once the payment has been done.

### Setup

This setup is done in the `MainApplication` class from `app` module, with : 

```
PaymentManager.init("MERCHANT_ID","http://MY_WS_URL");`
```
We gather the merchant id (in order to help check return url) and merchant server url to call dedicated web services. We prepare also everything neede for internals (http client stack ...)

### Prepare the payment

Firstly, we need to prepare the payment on the merchant server, with the following block : 

```
PaymentManager.get().preparePayment(new PaymentInit())`
```

It will post data to dedicated web service (url given in setup) :

`{ "vads_action_mode" : "WEBVIEW" }`

This method will return a result `PaymentInitResult`, which return _state_ (success/fail) and _redirect url_ for opening webview payment. 

__TODO :__ Complete service description (what post ws is used) / Service used here is post on "/performInit" url


### Display the payment

Once the previous method has been called, we have a `PaymentInitResult` result object from result json : 

`{ 'success' : true, 'redirect_url' = "..."}`

We now have to open a webview at given url and check for callbacks url. This is done with following block code (we also pass a callback activity, for later result):

```
PaymentManager.get().showPayment(result, activity, BackActivity.class);`
```

![Back View](./img/app-payment.png)

This method will open the webview and check every redirected url. If we have an url of type `http://webview_{merchantId}.<status>`, then we have a callback url and we can call the callback activity.


### CallBack Activity & Payment Result

In the callback activity, you can obtain the payment process result with the following code (in project, this is done in __BackActivity__) :

```
PaymentResult paymentResult = PaymentManager.get().getResultFromUrl(getIntent().getStringExtra(PaymentManager.BUNDLE_RESULT));
```

The result is composed of following :

* result status
* additional data (key/value map)

Then we are able to build a back activity, in coordination with status:

![Back View](./img/app-back.png)
![Back View](./img/app-back-fail.png)  
 
