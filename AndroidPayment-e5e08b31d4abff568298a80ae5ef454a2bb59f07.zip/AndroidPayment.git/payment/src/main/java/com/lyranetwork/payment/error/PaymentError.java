package com.lyranetwork.payment.error;

/**
 * Request Error
 */
public class PaymentError extends Exception {
    public PaymentError(String message, Exception e) {
        super(message, e);
    }

    public PaymentError(String s) {
        super(s);
    }
}
