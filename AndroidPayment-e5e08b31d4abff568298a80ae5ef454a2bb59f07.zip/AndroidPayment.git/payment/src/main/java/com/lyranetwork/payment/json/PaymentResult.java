package com.lyranetwork.payment.json;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by agiuliani on 21/09/2016.
 */

public class PaymentResult implements Serializable {

    private String result = "";

    private Map<String, String> additionalData = new HashMap<>();

    public PaymentResult(String res, String data) {
        result = res;
        String[] attributs = data.split("&");
        for (String att : attributs) {
            String[] prop = att.split("=");
            if (prop.length == 2) {
                additionalData.put(prop[0], prop[1]);
            } else if (prop.length == 1) {
                additionalData.put(prop[0], "");
            } else {
                System.out.println();
            }
        }
    }

    public String getResult() {
        return result;
    }

    public Map<String, String> getAdditionalData() {
        return additionalData;
    }

    public boolean isSuccess() {
        return result.toLowerCase().equals("success");
    }
}
