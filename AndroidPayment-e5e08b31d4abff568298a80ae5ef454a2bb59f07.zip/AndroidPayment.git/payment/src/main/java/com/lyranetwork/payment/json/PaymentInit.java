package com.lyranetwork.payment.json;

/**
 * Created by arnaud on 15/02/2017.
 */
public class PaymentInit {
    String vads_action_mode = "WEBVIEW";

    public String getVads_action_mode() {
        return vads_action_mode;
    }

    public void setVads_action_mode(String vads_action_mode) {
        this.vads_action_mode = vads_action_mode;
    }
}
