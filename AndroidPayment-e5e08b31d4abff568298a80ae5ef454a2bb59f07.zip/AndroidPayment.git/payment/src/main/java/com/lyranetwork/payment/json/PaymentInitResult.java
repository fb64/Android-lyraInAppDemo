package com.lyranetwork.payment.json;

/**
 * Created by agiuliani on 21/09/2016.
 */

public class PaymentInitResult {

    Boolean success = false;
    String redirect_url = "";

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getRedirect_url() {
        return redirect_url;
    }

    public void setRedirect_url(String redirect_url) {
        this.redirect_url = redirect_url;
    }

    public PaymentInitResult() {

    }
}
