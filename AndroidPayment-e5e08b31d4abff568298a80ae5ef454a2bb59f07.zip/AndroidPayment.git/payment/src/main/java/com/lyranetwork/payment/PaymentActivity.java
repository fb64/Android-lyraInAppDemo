package com.lyranetwork.payment;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.lyranetwork.paymentsdk.R;

import static com.lyranetwork.payment.PaymentManager.BUNDLE_RESULT;
import static com.lyranetwork.paymentsdk.R.id.webview;

/**
 * Payment web view activity
 */
public class PaymentActivity extends AppCompatActivity {

    private static final String TAG = PaymentActivity.class.getSimpleName();
    static String PAYZEN_URL = "PAYZEN_URL";
    private WebView mWebView;
    private String mUrl;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mUrl = getIntent().getExtras().getString(PAYZEN_URL);

        setContentView(R.layout.activity_payment);
        mWebView = (WebView) findViewById(webview);

        //force javascript
        mWebView.getSettings().setJavaScriptEnabled(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            if (0 != (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE)) {
                WebView.setWebContentsDebuggingEnabled(true);
            }
        }
        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                return super.onConsoleMessage(consoleMessage);
            }
        });
        mWebView.setWebViewClient(new WebViewClient() {
            @TargetApi(Build.VERSION_CODES.LOLLIPOP)
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return checkCurrentURL(view, request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return checkCurrentURL(view, url);
            }
        });
    }

    private boolean checkCurrentURL(WebView view, String url) {
        Boolean isCallBack = PaymentManager.get().isCallbackUrl(url);
        Log.w(TAG, "Handle callback ? " + isCallBack + " :: " + url);
        if (isCallBack) {
            view.stopLoading();
            goToBackActivity(view, url);
        } else {
            view.loadUrl(url);
        }
        return !isCallBack;
    }

    private void goToBackActivity(WebView view, String result) {
        Class<? extends Activity> callbackActivity = PaymentManager.get().getmCallbackActivity();
        Log.w(TAG, "Handle mUrl and redirect to " + callbackActivity);

        Context ctx = view.getContext();
        Intent intent = new Intent(ctx, PaymentManager.get().getmCallbackActivity());
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        ActivityOptionsCompat options = ActivityOptionsCompat.makeCustomAnimation(ctx, android.R.anim.fade_in, android.R.anim.fade_out);
        intent.putExtra(BUNDLE_RESULT, result);
        ActivityCompat.startActivity(PaymentActivity.this, intent, options.toBundle());
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (mUrl != null && !mUrl.isEmpty()) {
            mWebView.loadUrl(mUrl);
        }
    }
}
