import com.lyranetwork.payment.PaymentManager;
import com.lyranetwork.payment.json.PaymentResult;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by arnaud on 15/02/2017.
 */

public class TestPaymentResult {

    @Test
    public void testPaymentResult() {
        String url = "http://webview_91335531.success/?vads_amount=1524&vads_auth_mode=FULL&vads_auth_number=3fc746&vads_auth_result=00&vads_capture_delay=0&vads_card_brand=CB&vads_card_number=497010XXXXXX0000&vads_payment_certificate=86cf021e02446808822ef6b3a236c874afd5f28b&vads_ctx_mode=TEST&vads_currency=978&vads_effective_amount=1524&vads_effective_currency=978&vads_site_id=91335531&vads_trans_date=20170215151002&vads_trans_id=031002&vads_trans_uuid=3b02c5e97163477bbefe729488e2ca1f&vads_validation_mode=0&vads_version=V2&vads_warranty_result=YES&vads_payment_src=EC&vads_sequence_number=1&vads_contract_used=5785350&vads_trans_status=AUTHORISED&vads_expiry_month=6&vads_expiry_year=2018&vads_bank_code=17807&vads_bank_product=A&vads_pays_ip=FR&vads_presentation_date=20170215140936&vads_effective_creation_date=20170215140936&vads_operation_type=DEBIT&vads_threeds_enrolled=Y&vads_threeds_cavv=Q2F2dkNhdnZDYXZ2Q2F2dkNhdnY%3D&vads_threeds_eci=05&vads_threeds_xid=ZE9vWVNBaVlzdGZwRGNHczN1WTc%3D&vads_threeds_cavvAlgorithm=2&vads_threeds_status=Y&vads_threeds_sign_valid=1&vads_threeds_error_code=&vads_threeds_exit_status=10&vads_risk_control=CARD_FRAUD%3DOK&vads_result=00&vads_extra_result=00&vads_card_country=FR&vads_language=fr&vads_action_mode=WEBVIEW&vads_payment_config=SINGLE&vads_page_action=PAYMENT&strong_signature=74lZ7T1YRYZoCnnfHZ1wAP2FDOQor%2FPJIU6bs3TPkvM%3D&signature=4c60368fd075de97645a776363684e5e3e0aefa5";
        PaymentManager.init("91335531", "");
        PaymentResult result = PaymentManager.get().getResultFromUrl(url);
        assertTrue(result.isSuccess());
        assertEquals(50,result.getAdditionalData().size());
    }
}
