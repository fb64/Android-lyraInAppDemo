package com.lyranetwork.cheesecake;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.lyranetwork.cheesecake.data.Cart;
import com.lyranetwork.cheesecake.util.Navigation;

public class MainActivity extends AppCompatActivity {

    Cart myCart = MainApplication.get().getMyCart();
    private Button mPayButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView mTitle = (TextView) findViewById(R.id.main_title);
        mTitle.setTypeface(MainApplication.get().getIndieFlowerFont());

        RecyclerView mRecyclerView = (RecyclerView) findViewById(R.id.recycle_view);
        mRecyclerView.setHasFixedSize(true);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        MainListAdapter mAdapter = new MainListAdapter(MainApplication.AVAILABLE_ORDERS, this);
        mRecyclerView.setAdapter(mAdapter);
        mPayButton = (Button) findViewById(R.id.pay);

        mPayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MainApplication.get().getMyCart().count() > 0) {
                    goNext();
                }
            }
        });

        MainApplication.get().getMyCart().setOnCartAdded(new Cart.OnCartUpdate() {
            @Override
            public void onUpdate() {
                updatePaymentBar();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        updatePaymentBar();
    }

    void updatePaymentBar() {
        mPayButton.setText(myCart.count() + " " + getString(R.string.articles) + " " + myCart.total() + " €");
    }

    private void goNext() {
        Navigation.open(this, CartActivity.class, true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
