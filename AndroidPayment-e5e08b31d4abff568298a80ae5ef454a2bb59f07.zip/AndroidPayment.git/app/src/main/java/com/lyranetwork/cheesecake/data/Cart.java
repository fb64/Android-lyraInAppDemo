package com.lyranetwork.cheesecake.data;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by agiuliani on 26/09/2016.
 */

public class Cart {
    List<Order> orders = new ArrayList<>();
    OnCartUpdate callback;

    public int count(){
        return orders.size();
    }

    public Double total(){
        Double total = 0.0;
        for(Order o : orders){
            total += o.getPrice();
        }
        return total;
    }

    public void setOnCartAdded(OnCartUpdate onCartUpdate) {
        callback = onCartUpdate;
    }

    public void addOrder(Order order) {
        orders.add(order);
        callback.onUpdate();
    }

    public List<Order> getOrders() {
        return orders;
    }

    public void removeOrder(int order) {
        orders.remove(order);
        callback.onUpdate();
    }

    public static interface OnCartUpdate{
        void onUpdate();
    }
}
