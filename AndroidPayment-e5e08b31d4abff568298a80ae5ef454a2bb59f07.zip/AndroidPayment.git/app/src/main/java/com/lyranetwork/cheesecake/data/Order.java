package com.lyranetwork.cheesecake.data;

/**
 * Created by agiuliani on 26/09/2016.
 */

public class Order {

    String title;
    int imageId;
    Double price;

    public Order(String title, int imageId, Double price) {
        this.title = title;
        this.imageId = imageId;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public int getImageId() {
        return imageId;
    }

    public Double getPrice() {
        return price;
    }
}
