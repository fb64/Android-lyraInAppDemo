package com.lyranetwork.cheesecake;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.lyranetwork.cheesecake.util.Navigation;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        TextView title = (TextView) findViewById(R.id.splash);
        title.setTypeface(MainApplication.get().getIndieFlowerFont());

        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... params) {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                Navigation.open(SplashActivity.this, MainActivity.class, false);
            }
        }.execute();
    }

    @Override
    protected void onResume() {
        super.onResume();


    }
}
