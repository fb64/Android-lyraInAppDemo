package com.lyranetwork.cheesecake;

import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.lyranetwork.cheesecake.data.Order;

/**
 * Created by agiuliani on 26/09/2016.
 */

public class MainListAdapter extends RecyclerView.Adapter<MainListAdapter.ViewHolder> {

    private final MainActivity mActivity;
    private Order[] mDataset;

    // Provide a suitable constructor (depends on the kind of dataset)
    public MainListAdapter(Order[] myDataset, MainActivity activity) {
        mDataset = myDataset;
        mActivity = activity;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public MainListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                         int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_main, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        final Order order = mDataset[position];

        holder.mTitle.setText(order.getTitle());
        holder.mPrice.setText(String.format("%s €", order.getPrice()));
        if (order.getImageId() != 0) {
            Drawable drawable = MainApplication.get().getResources().getDrawable(order.getImageId());
            holder.mIamge.setImageDrawable(drawable);
        }
        holder.mCartLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainApplication.get().getMyCart().addOrder(order);
                mActivity.updatePaymentBar();
            }
        });
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset.length;
    }

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public TextView mTitle;
        public TextView mPrice;
        public ImageView mIamge;
        public LinearLayout mCartLayout;

        public ViewHolder(View v) {
            super(v);
            mTitle = (TextView) v.findViewById(R.id.item_main_title);
            mIamge = (ImageView) v.findViewById(R.id.item_main_image);
            mCartLayout = (LinearLayout) v.findViewById(R.id.content_cart);
            mPrice = (TextView) v.findViewById(R.id.item_main_price);
        }
    }
}